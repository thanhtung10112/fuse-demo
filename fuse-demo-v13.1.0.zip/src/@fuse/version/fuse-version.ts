import { Version } from '@fuse/version/version';

export const FUSE_VERSION = new Version('13.1.0').full;
